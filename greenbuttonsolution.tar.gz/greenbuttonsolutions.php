<?php
// no direct access
defined('_JEXEC') or die;

class plgContentgreenbuttonsolutions extends JPlugin
{
    public function onContentPrepare($context, &$row, &$params, $page = 0)
    {
        $dataapp = "broshline";
        $javascript = '<script src="http://greenbuttonsolutions.com/public/js/m.js" data-app="'. $dataapp .'"></script>';

        $document = JFactory::getDocument();
        $document->addCustomTag($javascript);

    }
}

?>