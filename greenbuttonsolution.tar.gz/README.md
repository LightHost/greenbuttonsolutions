A Joomla System plugin for Green Button Solutions JS service
